$(document).ready(function() {
    $('.department-name, .doctor-name, .time-during, .gender-name').select2();
});